function LVis_params = lt_lVis_init_settings

lt_lVis_settings_default
LVis_params = p;
