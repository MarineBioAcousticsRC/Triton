%%default settings for label visualization in LabelTracker remora. Created
%%by MAZ on 4/1/2020 (no foolin')

%visualize labels to load 
p.Load1check = 1;
p.Load2check = 0;
p.Load3check = 0;
p.Load4check = 0;

%use raw files for scanning 
p.rawFile = 'true';