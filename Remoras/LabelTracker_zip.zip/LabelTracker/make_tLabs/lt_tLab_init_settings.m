function TL_params = lt_tLab_init_settings

mk_tlab_settings_default
TL_params = p;
